  
 ## Credential for Admin panel :

> username: **admin**       
> password: **admin**

https://youtu.be/tTfn37NrzBw
