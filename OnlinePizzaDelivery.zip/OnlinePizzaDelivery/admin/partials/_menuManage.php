<?php
include '_dbconnect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    if (isset($_POST['createItem'])) {
        $name = mysqli_real_escape_string($conn, $_POST["name"]);
        $description = mysqli_real_escape_string($conn, $_POST["description"]);
        $categoryId = mysqli_real_escape_string($conn, $_POST["categoryId"]);
        $price = mysqli_real_escape_string($conn, $_POST["price"]);

        $sql = "INSERT INTO `pizza` (`pizzaName`, `pizzaPrice`, `pizzaDesc`, `pizzaCategorieId`, `pizzaPubDate`) VALUES ('$name', '$price', '$description', '$categoryId', current_timestamp())";
        if (mysqli_query($conn, $sql)) {
            $pizzaId = mysqli_insert_id($conn);
            $check = getimagesize($_FILES["image"]["tmp_name"]);
            if ($check !== false) {

                $newName = 'pizza-' . $pizzaId;
                $newfilename = $newName . ".jpg";

                $uploaddir = $_SERVER['DOCUMENT_ROOT'] . '/OnlinePizzaDelivery/img/';
                $uploadfile = $uploaddir . $newfilename;

                if (move_uploaded_file($_FILES['image']['tmp_name'], $uploadfile)) {
                    echo "<script>alert('Success');
                            window.location=document.referrer;
                        </script>";
                    exit();
                } else {
                    echo "<script>alert('Failed to upload image');
                            window.location=document.referrer;
                        </script>";
                    exit();
                }
            } else {
                echo '<script>alert("Please select an image file to upload.");
                        window.location=document.referrer;
                    </script>';
                exit();
            }
        } else {
            echo "<script>alert('Failed to create item: " . mysqli_error($conn) . "');
                    window.location=document.referrer;
                </script>";
            exit();
        }
    }

    if (isset($_POST['removeItem'])) {
        $pizzaId = mysqli_real_escape_string($conn, $_POST["pizzaId"]);
        $sql = "DELETE FROM `pizza` WHERE `pizzaId`='$pizzaId'";
        if (mysqli_query($conn, $sql)) {
            $filename = $_SERVER['DOCUMENT_ROOT'] . "/OnlinePizzaDelivery/img/pizza-" . $pizzaId . ".jpg";
            if (file_exists($filename)) {
                unlink($filename);
            }
            echo "<script>alert('Item removed successfully');
                    window.location=document.referrer;
                </script>";
            exit();
        } else {
            echo "<script>alert('Failed to remove item: " . mysqli_error($conn) . "');
                    window.location=document.referrer;
                </script>";
            exit();
        }
    }

    if (isset($_POST['updateItem'])) {
        $pizzaId = mysqli_real_escape_string($conn, $_POST["pizzaId"]);
        $pizzaName = mysqli_real_escape_string($conn, $_POST["name"]);
        $pizzaDesc = mysqli_real_escape_string($conn, $_POST["desc"]);
        $pizzaPrice = mysqli_real_escape_string($conn, $_POST["price"]);
        $pizzaCategorieId = mysqli_real_escape_string($conn, $_POST["catId"]);

        $sql = "UPDATE `pizza` SET `pizzaName`='$pizzaName', `pizzaPrice`='$pizzaPrice', `pizzaDesc`='$pizzaDesc', `pizzaCategorieId`='$pizzaCategorieId' WHERE `pizzaId`='$pizzaId'";
        if (mysqli_query($conn, $sql)) {
            echo "<script>alert('Item updated successfully');
                    window.location=document.referrer;
                </script>";
            exit();
        } else {
            echo "<script>alert('Failed to update item: " . mysqli_error($conn) . "');
                    window.location=document.referrer;
                </script>";
            exit();
        }
    }

    if (isset($_POST['updateItemPhoto'])) {
        $pizzaId = mysqli_real_escape_string($conn, $_POST["pizzaId"]);
        $check = getimagesize($_FILES["itemimage"]["tmp_name"]);
        if ($check !== false) {
            $newName = 'pizza-' . $pizzaId;
            $newfilename = $newName . ".jpg";

            $uploaddir = $_SERVER['DOCUMENT_ROOT'] . '/OnlinePizzaDelivery/img/';
            $uploadfile = $uploaddir . $newfilename;

            if (move_uploaded_file($_FILES['itemimage']['tmp_name'], $uploadfile)) {
                echo "<script>alert('Image updated successfully');
                        window.location=document.referrer;
                    </script>";
                exit();
            } else {
                echo "<script>alert('Failed to update image');
                        window.location=document.referrer;
                    </script>";
                exit();
            }
        } else {
            echo '<script>alert("Please select an image file to upload.");
                window.location=document.referrer;
                    </script>';
            exit();
        }
    }
}
?>
